# ClipForge

A local clipping studio. Paste a link or drop in a video, let Hype Finder find the loudest moments, cut the clips, and post them to YouTube and Instagram.

## What it does

- **Links:** YouTube, Twitch VODs and clips, and any site yt-dlp supports (1,000+). Downloaded at up to 1080p.
- **Files:** drag and drop MP4, MOV, MKV, WEBM, M4V or AVI. Large files upload with a progress bar.
- **Hype Finder:** reads the audio, ranks the moments where the room gets loud, and snaps each cut point to a quiet spot so clips never start or stop mid-word. Runs automatically when you open a source.
- **Make 5 Shorts:** renders the top five moments as 9:16 vertical clips in one click.
- **Clip editor:** keyboard in/out points, a loudness timeline with hype markers, and a live 9:16 or square crop preview.
- **Output formats:** 9:16 (Shorts and Reels), 1:1 square, or 16:9 original. Rendered as H.264 MP4.
- **Publish:** upload to YouTube (title, description, privacy) or post a Reel to Instagram.

## Requirements

- Python 3.9 or newer
- **ffmpeg** with ffprobe on your PATH
  - macOS: `brew install ffmpeg`
  - Ubuntu/Debian: `sudo apt install ffmpeg`
  - Windows: `winget install ffmpeg`, then reopen your terminal
- **yt-dlp** for pasted links: `python3 -m pip install -r requirements.txt`

No other Python packages are needed. Publishing uses only the standard library.

## Quick start

```bash
python3 -m pip install -r requirements.txt
python3 clipforge.py
```

Open http://localhost:8787.

The first time you start it, `data/` is created next to the script. It holds your media, rendered clips, and library. Delete it to start fresh.

## Using it

1. **Add a source.** Paste a link and press Enter, or drop a file on the left.
2. **Find the moments.** Hype Finder runs when the source opens. The yellow dots on the timeline are the hot spots. Click a moment in the Hype Finder panel to **Preview** it or **Clip it**.
3. **Or cut by hand.** Play or scrub to a point and press `I` for in and `O` for out. Pick a format, add an optional title, and press `C`.
4. **Publish.** Open a clip, press **Publish**, and fill in the YouTube or Instagram fields. Each platform button stays greyed out until that platform is connected.

| Key | Action |
|---|---|
| Space | Play / pause |
| I / O | Set in / out |
| C | Save clip from the current in and out |
| ← / → | Seek 5 seconds |

## Connect YouTube

1. In [Google Cloud Console](https://console.cloud.google.com/), create a project.
2. Enable **YouTube Data API v3** for it.
3. Under **Google Auth Platform**, set up the consent screen. Add your own Google account as a test user.
4. Under **Credentials**, create an **OAuth client ID** of type **Web application**.
5. Add this authorised redirect URI exactly: `http://localhost:8787/auth/youtube/callback`
6. Put the client ID and secret in your environment:
   ```bash
   export YOUTUBE_CLIENT_ID="...apps.googleusercontent.com"
   export YOUTUBE_CLIENT_SECRET="..."
   ```
7. Restart ClipForge, then click **Connect YouTube** in the header.

Tokens are saved in `data/youtube_tokens.json` with owner-only permissions. To sign out, stop the server and delete that file.

**Note:** Google limits uploads from API projects that have not been verified. Until your app is verified, uploads may be forced to private. The publish panel defaults to private.

## Connect Instagram

Instagram Reels need a few things that YouTube does not:

1. An Instagram **professional account** (Business or Creator), linked to a Facebook Page.
2. A Meta developer app with the Instagram content publishing permission. Your own account usually works in development mode, but check Meta's current requirements.
3. A long-lived access token and the Instagram user ID for that account.
4. A **public https address** for the video. Instagram downloads the file from a URL. Start a tunnel to ClipForge's port and set the address:
   ```bash
   ngrok http 8787        # or: cloudflared tunnel --url http://localhost:8787
   export CLIPFORGE_PUBLIC_URL="https://your-tunnel-address"
   export INSTAGRAM_USER_ID="..."
   export INSTAGRAM_ACCESS_TOKEN="..."
   ```

The tunnel only exposes rendered clips (`/clips/*.mp4`). Every other route returns 403 when reached through a non-local address, so your library and publishing controls stay on your machine.

Reels must be 3 to 90 seconds long. ClipForge checks this before posting.

## Configuration

| Variable | Default | Purpose |
|---|---|---|
| `CLIPFORGE_PORT` | `8787` | Port to serve on |
| `CLIPFORGE_HOST` | `127.0.0.1` | Interface to bind |
| `CLIPFORGE_DATA` | `./data` | Where media, clips and the library are stored |
| `CLIPFORGE_PUBLIC_URL` | empty | Public https address for Instagram |
| `YOUTUBE_CLIENT_ID` / `YOUTUBE_CLIENT_SECRET` | empty | YouTube OAuth client |
| `INSTAGRAM_USER_ID` / `INSTAGRAM_ACCESS_TOKEN` | empty | Instagram publishing |
| `INSTAGRAM_GRAPH_VERSION` | `v21.0` | Graph API version. Meta retires versions, so update this if calls start failing |
| `CLIPFORGE_LOG` | unset | Set to any value to log every request |

## Limits and things to know

- **Live streams:** ClipForge downloads finished streams and VODs. A live stream has to end before it can be imported.
- **Downloads:** Only clip content you own or have permission to use. Site terms of service still apply to downloads, and that responsibility is yours.
- **Hype Finder listens, it does not watch.** It finds loud moments, such as crowd noise, commentary spikes, goals or big laughs. A quiet but important moment, or a loud moment with nothing happening on screen, will be missed or misranked. Review the suggestions before posting.
- **One machine.** Everything runs locally. Your files never leave your computer unless you publish them.
- **Browser playback:** Chrome and Edge play most MP4s. Some codecs (HEVC in some builds, for example) may not preview in the browser. Rendering still works because it uses ffmpeg.

## Files

```
clipforge/
  clipforge.py       server: ingest, Hype Finder, rendering, YouTube and Instagram publishing
  index.html         the app (served by clipforge.py)
  requirements.txt   yt-dlp
  .env.example       every setting in one place
  README.md
```


## Visual AI and Autopilot (new)

ClipForge can now sample frames across an imported video and ask a vision-capable AI model to identify meaningful moments. It can create a short-form clip for each selected moment, generate a title/caption/description, and publish automatically to each configured platform.

### Enable visual analysis

1. Set `OPENAI_API_KEY` in the environment where ClipForge runs.
2. Optionally set `CLIPFORGE_VISION_MODEL` (defaults to `gpt-4o-mini`).
3. Restart ClipForge and open **AI Autopilot**.
4. Import and select a source video in **Studio**, then choose **Analyse selected video** or **Run Autopilot**.

Visual analysis sends a small set of sampled video frames to the configured AI provider. The source video itself is processed locally by FFmpeg; it is not uploaded to the AI provider by this feature.

### Enable automatic publishing

- **YouTube:** configure `YOUTUBE_CLIENT_ID` and `YOUTUBE_CLIENT_SECRET`, then connect your channel through the YouTube connection link. Autopilot publishes Shorts publicly.
- **Instagram:** configure `INSTAGRAM_USER_ID`, `INSTAGRAM_ACCESS_TOKEN`, and `CLIPFORGE_PUBLIC_URL` (an HTTPS address reachable by Meta). The account must meet Meta's professional-account and publishing requirements.
- Autopilot publishes to every platform that is fully connected. If one platform fails, the other platform is still attempted; errors are reported in the job result.
- Autopilot does not ask for per-clip approval after it is started. Only use content you own or have permission to publish. Review platform permissions and credentials before enabling it.

The refreshed interface separates **Studio**, **Clip library**, **AI Autopilot**, and **Connections & settings** into distinct views. Existing manual clipping, Hype Finder, rendering, and per-clip publishing remain available.
